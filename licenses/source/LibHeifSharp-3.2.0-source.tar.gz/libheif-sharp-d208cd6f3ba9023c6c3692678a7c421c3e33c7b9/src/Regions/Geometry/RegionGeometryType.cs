﻿/*
 * .NET bindings for libheif.
 * Copyright (c) 2020, 2021, 2022, 2023 Nicholas Hayes
 *
 * Portions Copyright (c) 2017 struktur AG, Dirk Farin <farin@struktur.de>
 *
 * This file is part of libheif-sharp.
 *
 * libheif-sharp is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * libheif-sharp is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with libheif-sharp.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace LibHeifSharp
{
    /// <summary>
    /// The type of geometry that a region represents.
    /// </summary>
    public enum RegionGeometryType
    {
        /// <summary>
        /// The region geometry is a point.
        /// </summary>
        Point = 0,

        /// <summary>
        /// The region geometry is a rectangle.
        /// </summary>
        Rectangle = 1,

        /// <summary>
        /// The region geometry is an ellipse.
        /// </summary>
        Ellipse = 2,

        /// <summary>
        /// The region geometry is a polygon.
        /// </summary>
        Polygon = 3,

        /// <summary>
        /// The region geometry is a referenced mask.
        /// </summary>
        ReferencedMask = 4,

        /// <summary>
        /// The region geometry is an in-line mask.
        /// </summary>
        InlineMask = 5,

        /// <summary>
        /// The region geometry is a polyline.
        /// </summary>
        Polyline = 6,
    }
}
